package com.example.registation1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Registation1Application {

	public static void main(String[] args) {
		SpringApplication.run(Registation1Application.class, args);
	}

}
