package com.example.registation1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Registation1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
